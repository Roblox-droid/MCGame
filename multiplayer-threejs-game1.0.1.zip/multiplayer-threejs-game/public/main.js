const socket = io();

// ----- Three.js setup -----
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x87CEEB); // sky blue

const camera = new THREE.PerspectiveCamera(60, window.innerWidth / window.innerHeight, 0.1, 1000);
camera.position.set(0, 15, 20);
camera.lookAt(0, 0, 0);

const renderer = new THREE.WebGLRenderer({ antialias: true });
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.shadowMap.enabled = true; // shadows add depth
document.body.appendChild(renderer.domElement);

// ----- Lighting -----
const ambientLight = new THREE.AmbientLight(0x404060);
scene.add(ambientLight);

const dirLight = new THREE.DirectionalLight(0xffffff, 1);
dirLight.position.set(5, 10, 7);
dirLight.castShadow = true;
dirLight.shadow.mapSize.width = 1024;
dirLight.shadow.mapSize.height = 1024;
const d = 15;
dirLight.shadow.camera.left = -d;
dirLight.shadow.camera.right = d;
dirLight.shadow.camera.top = d;
dirLight.shadow.camera.bottom = -d;
dirLight.shadow.camera.near = 1;
dirLight.shadow.camera.far = 20;
scene.add(dirLight);

// ----- Ground -----
const groundGeo = new THREE.PlaneGeometry(20, 20);
const groundMat = new THREE.MeshStandardMaterial({ color: 0x3c9e3c, side: THREE.DoubleSide });
const ground = new THREE.Mesh(groundGeo, groundMat);
ground.rotation.x = -Math.PI / 2;
ground.position.y = -0.5;
ground.receiveShadow = true;
scene.add(ground);

// Add a grid helper for better orientation
const gridHelper = new THREE.GridHelper(20, 20, 0xaaaaaa, 0x444444);
gridHelper.position.y = -0.49;
scene.add(gridHelper);

// ----- Game objects containers -----
const playersMesh = {};      // id -> THREE.Mesh
const collectiblesMesh = {}; // id -> THREE.Mesh

let myId = null;
let myScore = 0;

// ----- Load config from JSON (map size, colors etc.) -----
let config = {};
fetch('config.json')
  .then(res => res.json())
  .then(data => {
    config = data;
    console.log('Config loaded:', config);
    // Could adjust map size, colors, etc. here if needed
  });

// ----- Socket event handlers -----
socket.on('init', (data) => {
  myId = data.yourId;
  // Create existing players
  Object.values(data.players).forEach(player => addPlayer(player));
  // Create collectibles
  data.collectibles.forEach(c => addCollectible(c));
});

socket.on('playerJoined', (player) => {
  addPlayer(player);
});

socket.on('playerMoved', (data) => {
  const mesh = playersMesh[data.id];
  if (mesh) {
    mesh.position.x = data.x;
    mesh.position.z = data.z;
  }
});

socket.on('playerLeft', (id) => {
  if (playersMesh[id]) {
    scene.remove(playersMesh[id]);
    delete playersMesh[id];
  }
});

socket.on('collectibleMoved', (data) => {
  const mesh = collectiblesMesh[data.id];
  if (mesh) {
    mesh.position.x = data.x;
    mesh.position.z = data.z;
  }
});

socket.on('playerScored', (data) => {
  if (data.id === myId) {
    myScore = data.score;
    document.getElementById('score').textContent = myScore;
  }
  // Optionally update score display for other players? Not needed now.
});

// ----- Helper functions -----
function addPlayer(player) {
  // Create a cube for the player
  const geo = new THREE.BoxGeometry(1, 1, 1);
  const mat = new THREE.MeshStandardMaterial({ color: player.color });
  const cube = new THREE.Mesh(geo, mat);
  cube.castShadow = true;
  cube.receiveShadow = true;
  cube.position.set(player.x || 0, 0.5, player.z || 0);
  scene.add(cube);
  playersMesh[player.id] = cube;

  // If it's me, add a little marker (e.g., a small sphere on top)
  if (player.id === myId) {
    const markerGeo = new THREE.SphereGeometry(0.2, 8, 8);
    const markerMat = new THREE.MeshStandardMaterial({ color: 0xffaa00 });
    const marker = new THREE.Mesh(markerGeo, markerMat);
    marker.position.y = 1;
    cube.add(marker);
  }
}

function addCollectible(c) {
  // Create a sphere for the collectible
  const geo = new THREE.SphereGeometry(0.5, 16, 16);
  const mat = new THREE.MeshStandardMaterial({ color: 0xffaa00, emissive: 0x442200 });
  const sphere = new THREE.Mesh(geo, mat);
  sphere.castShadow = true;
  sphere.receiveShadow = true;
  sphere.position.set(c.x, 0.5, c.z);
  scene.add(sphere);
  collectiblesMesh[c.id] = sphere;
}

// ----- Movement handling (keyboard + touch buttons) -----
let moveState = { up: false, down: false, left: false, right: false };

function sendMove() {
  socket.emit('move', moveState);
}

// Keyboard controls
window.addEventListener('keydown', (e) => {
  switch(e.key) {
    case 'ArrowUp': e.preventDefault(); moveState.up = true; sendMove(); break;
    case 'ArrowDown': e.preventDefault(); moveState.down = true; sendMove(); break;
    case 'ArrowLeft': e.preventDefault(); moveState.left = true; sendMove(); break;
    case 'ArrowRight': e.preventDefault(); moveState.right = true; sendMove(); break;
  }
});

window.addEventListener('keyup', (e) => {
  switch(e.key) {
    case 'ArrowUp': moveState.up = false; sendMove(); break;
    case 'ArrowDown': moveState.down = false; sendMove(); break;
    case 'ArrowLeft': moveState.left = false; sendMove(); break;
    case 'ArrowRight': moveState.right = false; sendMove(); break;
  }
});

// Touch button controls
document.getElementById('up').addEventListener('mousedown', (e) => { e.preventDefault(); moveState.up = true; sendMove(); });
document.getElementById('up').addEventListener('mouseup', (e) => { moveState.up = false; sendMove(); });
document.getElementById('up').addEventListener('mouseleave', (e) => { moveState.up = false; sendMove(); });
document.getElementById('down').addEventListener('mousedown', (e) => { e.preventDefault(); moveState.down = true; sendMove(); });
document.getElementById('down').addEventListener('mouseup', (e) => { moveState.down = false; sendMove(); });
document.getElementById('down').addEventListener('mouseleave', (e) => { moveState.down = false; sendMove(); });
document.getElementById('left').addEventListener('mousedown', (e) => { e.preventDefault(); moveState.left = true; sendMove(); });
document.getElementById('left').addEventListener('mouseup', (e) => { moveState.left = false; sendMove(); });
document.getElementById('left').addEventListener('mouseleave', (e) => { moveState.left = false; sendMove(); });
document.getElementById('right').addEventListener('mousedown', (e) => { e.preventDefault(); moveState.right = true; sendMove(); });
document.getElementById('right').addEventListener('mouseup', (e) => { moveState.right = false; sendMove(); });
document.getElementById('right').addEventListener('mouseleave', (e) => { moveState.right = false; sendMove(); });

// Also handle touch events for mobile
['up', 'down', 'left', 'right'].forEach(id => {
  const btn = document.getElementById(id);
  btn.addEventListener('touchstart', (e) => { e.preventDefault(); moveState[id] = true; sendMove(); });
  btn.addEventListener('touchend', (e) => { e.preventDefault(); moveState[id] = false; sendMove(); });
  btn.addEventListener('touchcancel', (e) => { e.preventDefault(); moveState[id] = false; sendMove(); });
});

// ----- Animation loop -----
function animate() {
  requestAnimationFrame(animate);

  // Optional: simple floating animation for collectibles
  Object.values(collectiblesMesh).forEach(mesh => {
    mesh.rotation.y += 0.02;
    mesh.position.y = 0.5 + Math.sin(Date.now() * 0.005) * 0.2;
  });

  // Camera follows my player? Here we keep it fixed, but we could make it follow.
  // For now, static camera.

  renderer.render(scene, camera);
}
animate();

// ----- Handle window resize -----
window.addEventListener('resize', onWindowResize, false);
function onWindowResize() {
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
}