const express = require('express');
const http = require('http');
const socketIo = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = socketIo(server);

app.use(express.static('public'));

// Game state
let players = {};
let collectibles = [];
const COLLECTIBLE_COUNT = 5;
const MAP_SIZE = 20; // from -10 to 10
const PLAYER_SPEED = 0.1;

// Initialize collectibles at random positions
function initCollectibles() {
  collectibles = [];
  for (let i = 0; i < COLLECTIBLE_COUNT; i++) {
    collectibles.push({
      id: `c${i}`,
      x: (Math.random() - 0.5) * MAP_SIZE,
      z: (Math.random() - 0.5) * MAP_SIZE,
    });
  }
}
initCollectibles();

// Helper: check collision between player and collectible
function checkCollection(player) {
  for (let i = 0; i < collectibles.length; i++) {
    const c = collectibles[i];
    const dx = player.x - c.x;
    const dz = player.z - c.z;
    const dist = Math.sqrt(dx * dx + dz * dz);
    if (dist < 1.5) { // collision threshold
      // Increase player's score
      player.score = (player.score || 0) + 1;

      // Respawn collectible
      c.x = (Math.random() - 0.5) * MAP_SIZE;
      c.z = (Math.random() - 0.5) * MAP_SIZE;

      // Broadcast updated collectible and player score
      io.emit('collectibleMoved', { id: c.id, x: c.x, z: c.z });
      io.emit('playerScored', { id: player.id, score: player.score });
    }
  }
}

io.on('connection', (socket) => {
  console.log('a user connected:', socket.id);

  // Send current game state to new player
  socket.emit('init', {
    players: players,
    collectibles: collectibles,
    yourId: socket.id
  });

  // Create new player
  players[socket.id] = {
    id: socket.id,
    x: 0,
    z: 0,
    color: `hsl(${Math.random() * 360}, 100%, 50%)`,
    score: 0
  };

  // Broadcast new player to others
  socket.broadcast.emit('playerJoined', players[socket.id]);

  // Handle movement
  socket.on('move', (dir) => {
    const player = players[socket.id];
    if (!player) return;

    // Update position based on direction
    if (dir.up) player.z -= PLAYER_SPEED;
    if (dir.down) player.z += PLAYER_SPEED;
    if (dir.left) player.x -= PLAYER_SPEED;
    if (dir.right) player.x += PLAYER_SPEED;

    // Keep within map bounds
    const limit = MAP_SIZE / 2 - 1;
    player.x = Math.max(-limit, Math.min(limit, player.x));
    player.z = Math.max(-limit, Math.min(limit, player.z));

    // Check for collectible collisions
    checkCollection(player);

    // Broadcast new position
    io.emit('playerMoved', { id: socket.id, x: player.x, z: player.z });
  });

  // Handle disconnection
  socket.on('disconnect', () => {
    console.log('user disconnected:', socket.id);
    delete players[socket.id];
    io.emit('playerLeft', socket.id);
  });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});